# E-commerce Analytics Pipeline
Synthetic data generation + transformations + Looker dashboard.
