INSERT INTO `ecommerce-analytics-12345.raw_data.products_raw`
VALUES
("P001","Noise-Cancelling Headphones","Electronics",120),
("P002","Smart Fitness Watch","Wearables",90),
("P003","Ergonomic Office Chair","Furniture",250),
("P004","Mechanical Keyboard","Accessories",70),
("P005","Portable Speaker","Electronics",55);
